package Processos;

import junit.framework.TestCase;

public class ExecutaTeste extends TestCase{

	public void testExecutaTeste(){
		
		float InformaValor1 = 10;
		float InformaValor2 = 6;
		float ResultadoEsperado = 16;
		
		
		
		float ResultadoReal = Calculos.ExecutaTeste(InformaValor1, InformaValor2);
	
		assertEquals(ResultadoEsperado, ResultadoReal, 0);
	}

}
