package Processos;

public class Calculos {
	
	public static float ExecutaTeste(float Valor1, float Valor2){
		float Soma = Valor1 + Valor2;
		return Soma;
	}

}
