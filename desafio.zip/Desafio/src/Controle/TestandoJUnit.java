package Controle;
import org.junit.Assert;
import org.junit.Test;
 
public class TestandoJUnit {
 
	@Test
	public void testeConfiguracao(){
		Assert.assertEquals(2, (1+1), 0);
	}
}