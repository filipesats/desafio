package Controle;

import junit.framework.TestCase;

public class SuperClassTeste extends TestCase{

}
